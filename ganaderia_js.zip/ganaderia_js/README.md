# Gestión Ganadera — CRUD con herencia y polimorfismo (JavaScript + SQL Server)

## Estructura
```
host/            Conexión a SQL Server (config.js + conexion.js)
modelos/         Entidad.js (clase abstracta) + Raza, Enfermedad, Bovino,
                 Tratamiento, Historial (heredan de Entidad) + FabricaEntidad.js
controladores/   crudController.js — un solo controlador, polimórfico
rutas/           rutasApi.js — endpoints REST
public/          index.html, css/estilos.css, js/app.js (frontend dinámico)
bd/              script_crear_base_datos.sql (DDL con FKs según tu diagrama)
server.js        Punto de arranque (Express)
package.json
```

## 1. Crea la base de datos
En SQL Server Management Studio (o sqlcmd):
```sql
CREATE DATABASE GanaderiaDB;
```
Luego ejecuta `bd/script_crear_base_datos.sql` sobre esa base.

## 2. Configura la conexión (carpeta `host/`)
Edita `host/config.js` con tus datos, o define variables de entorno antes de
arrancar (recomendado):
```
set DB_SERVIDOR=localhost
set DB_NOMBRE=GanaderiaDB
set DB_USUARIO=sa
set DB_CLAVE=tu_password
```

## 3. Instala dependencias y arranca
```bash
npm install
npm start
```
Abre `http://localhost:3000`.

## Cómo se ven la herencia y el polimorfismo aquí
- `Entidad` (modelos/Entidad.js) es la clase abstracta: no se puede
  instanciar directamente y define el motor CRUD genérico (crear, listar,
  actualizar, eliminar) más dos métodos que obliga a implementar a sus
  hijas: `obtenerCampos()` y `validar()`.
- `Raza`, `Enfermedad`, `Bovino`, `Tratamiento` e `Historial` heredan de
  `Entidad` e implementan esos métodos con su propia lógica. `Bovino`,
  `Tratamiento` e `Historial` además sobreescriben `listar()` para traer
  los datos relacionados (JOIN) — ese es el polimorfismo: el controlador
  llama siempre a `modelo.listar()` sin saber (ni importarle) cuál
  subclase concreta está usando.
- El frontend (`public/js/app.js`) no tiene ni una tabla ni un formulario
  "quemado": construye todo leyendo `obtenerCampos()` y `opciones` desde
  la API, así que agregar una entidad nueva en el backend la hace
  aparecer automáticamente en la interfaz.
