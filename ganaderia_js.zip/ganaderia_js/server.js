import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import rutasApi from './rutas/rutasApi.js';

/**
 * server.js
 * -----------------------------------------------------------------
 * Punto de arranque de todo el proyecto. Crea el servidor Express,
 * lo conecta con las rutas de la API (/api/...) y también sirve los
 * archivos estáticos del frontend (HTML, CSS, JS) desde /public.
 * Todo corre en el mismo puerto, por eso el navegador puede pedir
 * tanto la página como los datos sin problemas de CORS.
 *
 * En ES Modules no existen "__dirname" ni "__filename" por defecto
 * (sí existían en CommonJS): estas dos líneas los reconstruyen a
 * partir de "import.meta.url", que es lo que sí trae cada módulo ESM.
 */
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PUERTO = process.env.PORT || 3000;

app.use(express.json());                                  // permite leer JSON en el body de POST/PUT
app.use('/api', rutasApi);                                 // todo lo que empiece con /api/... va al backend
app.use(express.static(path.join(__dirname, 'public')));   // el resto (html, css, js) se sirve tal cual

// Cualquier otra ruta (por ejemplo, recargar la página en "#/bovino")
// cae siempre al mismo index.html; el enrutado real lo hace el propio
// frontend con el "hash" de la URL (ver public/js/app.js).
app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PUERTO, () => {
  console.log(`Gestión Ganadera activo en http://localhost:${PUERTO}`);
});
