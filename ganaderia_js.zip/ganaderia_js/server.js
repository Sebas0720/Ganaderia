const express = require('express');
const path = require('path');
const rutasApi = require('./rutas/rutasApi');

const app = express();
const PUERTO = process.env.PORT || 3000;

app.use(express.json());
app.use('/api', rutasApi);
app.use(express.static(path.join(__dirname, 'public')));

app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PUERTO, () => {
  console.log(`Gestión Ganadera activo en http://localhost:${PUERTO}`);
});
