/**
 * app.js
 * -----------------------------------------------------------------
 * Todo el frontend vive en esta clase (AplicacionGanadera). No hay
 * tablas ni formularios "quemados" en el HTML: se construyen en
 * caliente leyendo lo que la API expone (obtenerCampos, opciones,
 * registros) -> valores siempre dinámicos, nunca fijos en el código.
 *
 * ENCAPSULAMIENTO: las tres referencias al DOM (#contenedor,
 * #navEntidades, #tituloVista) son CAMPOS PRIVADOS: solo los métodos
 * de esta clase pueden tocarlas. Los métodos internos que nadie de
 * afuera debería llamar directamente (#obtenerJSON, #mostrarPanel,
 * #mostrarListado, #mostrarFormulario, #construirControl) también son
 * privados; la única puerta de entrada pública es iniciar().
 */
class AplicacionGanadera {
  #contenedor;
  #navEntidades;
  #tituloVista;

  constructor() {
    this.#contenedor = document.getElementById('contenido');
    this.#navEntidades = document.getElementById('nav-entidades');
    this.#tituloVista = document.getElementById('titulo-vista');
  }

  // Getter privado derivado: separa el "#/bovino/editar/5" del hash en
  // ["bovino", "editar", "5"], para no repetir este parsing en cada
  // método que lo necesita.
  get #partesRuta() {
    const ruta = window.location.hash.replace('#/', '');
    return ruta.split('/').filter(Boolean);
  }

  // Pide datos a la API y devuelve el JSON ya listo para usar. Si la
  // respuesta no viene bien (status distinto de 2xx), arma un mensaje
  // de error legible (sin importar si el backend mandó un texto simple
  // o un objeto de error más complejo) y lo lanza como excepción.
  async #obtenerJSON(url, opciones = {}) {
    const respuesta = await fetch(url, opciones);
    const datos = await respuesta.json().catch(() => ({}));
    if (!respuesta.ok) {
      let mensaje = 'Ocurrió un error inesperado';
      if (typeof datos.error === 'string') {
        mensaje = datos.error;
      } else if (datos.error && typeof datos.error === 'object') {
        mensaje = datos.error.message || JSON.stringify(datos.error);
      }
      throw new Error(mensaje);
    }
    return datos;
  }

  // Reconstruye el menú superior (Panel + una entrada por cada
  // entidad) y marca como "activa" la que corresponda a la vista actual.
  async #construirNavegacion(entidadActiva) {
    const entidades = await this.#obtenerJSON('/api/entidades');
    this.#navEntidades.innerHTML = '';

    const enlaceInicio = document.createElement('a');
    enlaceInicio.href = '#/';
    enlaceInicio.textContent = 'Panel';
    enlaceInicio.className = entidadActiva ? '' : 'activo';
    this.#navEntidades.appendChild(enlaceInicio);

    entidades.forEach(({ clave, titulo }) => {
      const enlace = document.createElement('a');
      enlace.href = `#/${clave}`;
      enlace.textContent = titulo;
      enlace.className = clave === entidadActiva ? 'activo' : '';
      this.#navEntidades.appendChild(enlace);
    });
  }

  // Vista "Panel principal": una tarjeta por entidad, con el total de
  // registros que tiene en ese momento (consultado en vivo, no un número fijo).
  async #mostrarPanel() {
    this.#tituloVista.textContent = 'Panel principal';
    await this.#construirNavegacion(null);

    const entidades = await this.#obtenerJSON('/api/entidades');
    const tarjetas = await Promise.all(
      entidades.map(async ({ clave, titulo }) => {
        const registros = await this.#obtenerJSON(`/api/${clave}`);
        return { clave, titulo, total: registros.length };
      })
    );

    this.#contenedor.innerHTML = `
      <section class="panel">
        <p class="panel__intro">Selecciona un módulo para administrar la información del hato ganadero. Los datos se consultan en tiempo real desde SQL Server.</p>
        <div class="tarjetas">
          ${tarjetas
            .map(
              (t, i) => `
            <a class="tarjeta tarjeta--acento${(i % 3) + 1}" href="#/${t.clave}">
              <span class="tarjeta__numero">${t.total}</span>
              <span class="tarjeta__etiqueta">${t.titulo}</span>
            </a>`
            )
            .join('')}
        </div>
      </section>
    `;
  }

  // Vista de listado: tabla dinámica (las columnas salen de
  // obtenerCampos()) con acciones de Editar / Eliminar por fila.
  async #mostrarListado(entidad) {
    const { campos, llavePrimaria, titulo } = await this.#obtenerJSON(`/api/${entidad}/campos`);
    this.#tituloVista.textContent = titulo;
    await this.#construirNavegacion(entidad);

    const registros = await this.#obtenerJSON(`/api/${entidad}`);
    const nombresCampos = Object.entries(campos);

    this.#contenedor.innerHTML = `
      <section class="panel">
        <div class="panel__acciones">
          <a class="boton boton--primario" href="#/${entidad}/nuevo">+ Nuevo registro</a>
        </div>
        ${
          registros.length === 0
            ? `<p class="vacio">Todavía no hay registros de ${titulo.toLowerCase()}. Crea el primero.</p>`
            : `
        <div class="tabla-envoltorio">
        <table class="tabla">
          <thead>
            <tr>
              <th>#</th>
              ${nombresCampos.map(([, def]) => `<th>${def.etiqueta}</th>`).join('')}
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            ${registros
              .map(
                (fila) => `
              <tr>
                <td>${fila[llavePrimaria]}</td>
                ${nombresCampos
                  .map(([nombreCampo, def]) => {
                    const valor =
                      def.tipo === 'select' && def.etiquetaRelacion && fila[def.etiquetaRelacion] !== undefined
                        ? fila[def.etiquetaRelacion]
                        : fila[nombreCampo];
                    return `<td>${valor ?? ''}</td>`;
                  })
                  .join('')}
                <td class="tabla__acciones">
                  <a href="#/${entidad}/editar/${fila[llavePrimaria]}">Editar</a>
                  <button class="enlace-eliminar" data-id="${fila[llavePrimaria]}">Eliminar</button>
                </td>
              </tr>`
              )
              .join('')}
          </tbody>
        </table>
        </div>`
        }
      </section>
    `;

    this.#contenedor.querySelectorAll('.enlace-eliminar').forEach((boton) => {
      boton.addEventListener('click', async () => {
        if (!confirm('¿Eliminar este registro de forma permanente?')) return;
        try {
          await this.#obtenerJSON(`/api/${entidad}/${boton.dataset.id}`, { method: 'DELETE' });
          this.#mostrarListado(entidad);
        } catch (error) {
          alert(error.message);
        }
      });
    });
  }

  // Vista de formulario (crear o editar, según si llega "id"). Los
  // campos del formulario y las opciones de los <select> se arman
  // dinámicamente a partir de lo que responde la API.
  async #mostrarFormulario(entidad, id = null) {
    const { campos, llavePrimaria, titulo } = await this.#obtenerJSON(`/api/${entidad}/campos`);
    const opciones = await this.#obtenerJSON(`/api/${entidad}/opciones`);
    const registro = id
      ? await this.#obtenerJSON(`/api/${entidad}`).then((lista) => lista.find((r) => String(r[llavePrimaria]) === String(id)))
      : null;

    this.#tituloVista.textContent = `${id ? 'Editar' : 'Nuevo'} · ${titulo}`;
    await this.#construirNavegacion(entidad);

    this.#contenedor.innerHTML = `
      <section class="panel">
        <a class="volver" href="#/${entidad}">&larr; Volver al listado</a>
        <h2 class="panel__titulo">${id ? 'Editar' : 'Nuevo'} registro — ${titulo}</h2>
        <div class="alerta alerta--error oculto" id="mensaje-error"></div>
        <form class="formulario" id="formulario-crud">
          ${Object.entries(campos)
            .map(
              ([nombreCampo, def]) => `
            <div class="campo">
              <label for="${nombreCampo}">${def.etiqueta}${def.requerido ? ' *' : ''}</label>
              ${this.#construirControl(nombreCampo, def, registro, opciones)}
            </div>`
            )
            .join('')}
          <div class="formulario__acciones">
            <button type="submit" class="boton boton--primario">Guardar</button>
            <a href="#/${entidad}" class="boton boton--secundario">Cancelar</a>
          </div>
        </form>
      </section>
    `;

    document.getElementById('formulario-crud').addEventListener('submit', async (evento) => {
      evento.preventDefault();
      const datosFormulario = new FormData(evento.target);
      const cuerpo = Object.fromEntries(datosFormulario.entries());

      try {
        if (id) {
          await this.#obtenerJSON(`/api/${entidad}/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(cuerpo),
          });
        } else {
          await this.#obtenerJSON(`/api/${entidad}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(cuerpo),
          });
        }
        window.location.hash = `#/${entidad}`;
      } catch (error) {
        const cajaError = document.getElementById('mensaje-error');
        cajaError.textContent = error.message;
        cajaError.classList.remove('oculto');
      }
    });
  }

  // Construye el <input>/<select>/<textarea> adecuado según el "tipo"
  // que declaró el modelo en obtenerCampos().
  #construirControl(nombreCampo, def, registro, opciones) {
    const valorActual = registro ? registro[nombreCampo] ?? '' : '';
    const requerido = def.requerido ? 'required' : '';

    if (def.tipo === 'select') {
      const fuente = opciones[nombreCampo] || { llave: 'id', registros: [] };
      const opcionesHtml = fuente.registros
        .map((opcion) => {
          const valor = opcion[fuente.llave];
          const etiqueta = opcion[def.etiquetaRelacion] ?? valor;
          const seleccionado = String(valorActual) === String(valor) ? 'selected' : '';
          return `<option value="${valor}" ${seleccionado}>${etiqueta}</option>`;
        })
        .join('');
      return `<select id="${nombreCampo}" name="${nombreCampo}" ${requerido}>
        <option value="">Selecciona una opción</option>
        ${opcionesHtml}
      </select>`;
    }

    if (def.tipo === 'textarea') {
      return `<textarea id="${nombreCampo}" name="${nombreCampo}" rows="3" ${requerido}>${valorActual}</textarea>`;
    }

    return `<input type="${def.tipo}" id="${nombreCampo}" name="${nombreCampo}" value="${valorActual}" ${requerido}>`;
  }

  // Único método público que decide qué vista mostrar, según el hash
  // actual de la URL ("#/", "#/bovino", "#/bovino/nuevo", "#/bovino/editar/5").
  async enrutar() {
    const partes = this.#partesRuta;

    try {
      if (partes.length === 0) {
        await this.#mostrarPanel();
      } else if (partes.length === 1) {
        await this.#mostrarListado(partes[0]);
      } else if (partes[1] === 'nuevo') {
        await this.#mostrarFormulario(partes[0]);
      } else if (partes[1] === 'editar') {
        await this.#mostrarFormulario(partes[0], partes[2]);
      }
    } catch (error) {
      this.#contenedor.innerHTML = `<div class="alerta alerta--error">${error.message}</div>`;
    }
  }

  // Conecta los eventos del navegador con enrutar(): al cargar la
  // página y cada vez que cambia el "#" de la URL.
  iniciar() {
    window.addEventListener('hashchange', () => this.enrutar());
    window.addEventListener('DOMContentLoaded', () => this.enrutar());
  }
}

const aplicacion = new AplicacionGanadera();
aplicacion.iniciar();
