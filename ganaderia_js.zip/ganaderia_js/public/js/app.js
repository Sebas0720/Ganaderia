const contenedor = document.getElementById('contenido');
const navEntidades = document.getElementById('nav-entidades');
const tituloVista = document.getElementById('titulo-vista');

async function obtenerJSON(url, opciones = {}) {
  const respuesta = await fetch(url, opciones);
  const datos = await respuesta.json().catch(() => ({}));
  if (!respuesta.ok) {
    let mensaje = 'Ocurrió un error inesperado';
    if (typeof datos.error === 'string') {
      mensaje = datos.error;
    } else if (datos.error && typeof datos.error === 'object') {
      mensaje = datos.error.message || JSON.stringify(datos.error);
    }
    throw new Error(mensaje);
  }
  return datos;
}

async function construirNavegacion(entidadActiva) {
  const entidades = await obtenerJSON('/api/entidades');
  navEntidades.innerHTML = '';

  const enlaceInicio = document.createElement('a');
  enlaceInicio.href = '#/';
  enlaceInicio.textContent = 'Panel';
  enlaceInicio.className = entidadActiva ? '' : 'activo';
  navEntidades.appendChild(enlaceInicio);

  entidades.forEach(({ clave, titulo }) => {
    const enlace = document.createElement('a');
    enlace.href = `#/${clave}`;
    enlace.textContent = titulo;
    enlace.className = clave === entidadActiva ? 'activo' : '';
    navEntidades.appendChild(enlace);
  });
}

async function mostrarPanel() {
  tituloVista.textContent = 'Panel principal';
  await construirNavegacion(null);

  const entidades = await obtenerJSON('/api/entidades');
  const tarjetas = await Promise.all(
    entidades.map(async ({ clave, titulo }) => {
      const registros = await obtenerJSON(`/api/${clave}`);
      return { clave, titulo, total: registros.length };
    })
  );

  contenedor.innerHTML = `
    <section class="panel">
      <p class="panel__intro">Selecciona un módulo para administrar la información del hato ganadero. Los datos se consultan en tiempo real desde SQL Server.</p>
      <div class="tarjetas">
        ${tarjetas
          .map(
            (t, i) => `
          <a class="tarjeta tarjeta--acento${(i % 3) + 1}" href="#/${t.clave}">
            <span class="tarjeta__numero">${t.total}</span>
            <span class="tarjeta__etiqueta">${t.titulo}</span>
          </a>`
          )
          .join('')}
      </div>
    </section>
  `;
}

async function mostrarListado(entidad) {
  const { campos, llavePrimaria, titulo } = await obtenerJSON(`/api/${entidad}/campos`);
  tituloVista.textContent = titulo;
  await construirNavegacion(entidad);

  const registros = await obtenerJSON(`/api/${entidad}`);
  const nombresCampos = Object.entries(campos);

  contenedor.innerHTML = `
    <section class="panel">
      <div class="panel__acciones">
        <a class="boton boton--primario" href="#/${entidad}/nuevo">+ Nuevo registro</a>
      </div>
      ${
        registros.length === 0
          ? `<p class="vacio">Todavía no hay registros de ${titulo.toLowerCase()}. Crea el primero.</p>`
          : `
      <div class="tabla-envoltorio">
      <table class="tabla">
        <thead>
          <tr>
            <th>#</th>
            ${nombresCampos.map(([, def]) => `<th>${def.etiqueta}</th>`).join('')}
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          ${registros
            .map(
              (fila) => `
            <tr>
              <td>${fila[llavePrimaria]}</td>
              ${nombresCampos
                .map(([nombreCampo, def]) => {
                  const valor =
                    def.tipo === 'select' && def.etiquetaRelacion && fila[def.etiquetaRelacion] !== undefined
                      ? fila[def.etiquetaRelacion]
                      : fila[nombreCampo];
                  return `<td>${valor ?? ''}</td>`;
                })
                .join('')}
              <td class="tabla__acciones">
                <a href="#/${entidad}/editar/${fila[llavePrimaria]}">Editar</a>
                <button class="enlace-eliminar" data-id="${fila[llavePrimaria]}">Eliminar</button>
              </td>
            </tr>`
            )
            .join('')}
        </tbody>
      </table>
      </div>`
      }
    </section>
  `;

  contenedor.querySelectorAll('.enlace-eliminar').forEach((boton) => {
    boton.addEventListener('click', async () => {
      if (!confirm('¿Eliminar este registro de forma permanente?')) return;
      try {
        await obtenerJSON(`/api/${entidad}/${boton.dataset.id}`, { method: 'DELETE' });
        mostrarListado(entidad);
      } catch (error) {
        alert(error.message);
      }
    });
  });
}

async function mostrarFormulario(entidad, id = null) {
  const { campos, llavePrimaria, titulo } = await obtenerJSON(`/api/${entidad}/campos`);
  const opciones = await obtenerJSON(`/api/${entidad}/opciones`);
  const registro = id
    ? await obtenerJSON(`/api/${entidad}`).then((lista) => lista.find((r) => String(r[llavePrimaria]) === String(id)))
    : null;

  tituloVista.textContent = `${id ? 'Editar' : 'Nuevo'} · ${titulo}`;
  await construirNavegacion(entidad);

  contenedor.innerHTML = `
    <section class="panel">
      <a class="volver" href="#/${entidad}">&larr; Volver al listado</a>
      <h2 class="panel__titulo">${id ? 'Editar' : 'Nuevo'} registro — ${titulo}</h2>
      <div class="alerta alerta--error oculto" id="mensaje-error"></div>
      <form class="formulario" id="formulario-crud">
        ${Object.entries(campos)
          .map(
            ([nombreCampo, def]) => `
          <div class="campo">
            <label for="${nombreCampo}">${def.etiqueta}${def.requerido ? ' *' : ''}</label>
            ${construirControl(nombreCampo, def, registro, opciones)}
          </div>`
          )
          .join('')}
        <div class="formulario__acciones">
          <button type="submit" class="boton boton--primario">Guardar</button>
          <a href="#/${entidad}" class="boton boton--secundario">Cancelar</a>
        </div>
      </form>
    </section>
  `;

  document.getElementById('formulario-crud').addEventListener('submit', async (evento) => {
    evento.preventDefault();
    const datosFormulario = new FormData(evento.target);
    const cuerpo = Object.fromEntries(datosFormulario.entries());

    try {
      if (id) {
        await obtenerJSON(`/api/${entidad}/${id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(cuerpo),
        });
      } else {
        await obtenerJSON(`/api/${entidad}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(cuerpo),
        });
      }
      window.location.hash = `#/${entidad}`;
    } catch (error) {
      const cajaError = document.getElementById('mensaje-error');
      cajaError.textContent = error.message;
      cajaError.classList.remove('oculto');
    }
  });
}

function construirControl(nombreCampo, def, registro, opciones) {
  const valorActual = registro ? registro[nombreCampo] ?? '' : '';
  const requerido = def.requerido ? 'required' : '';

  if (def.tipo === 'select') {
    const fuente = opciones[nombreCampo] || { llave: 'id', registros: [] };
    const opcionesHtml = fuente.registros
      .map((opcion) => {
        const valor = opcion[fuente.llave];
        const etiqueta = opcion[def.etiquetaRelacion] ?? valor;
        const seleccionado = String(valorActual) === String(valor) ? 'selected' : '';
        return `<option value="${valor}" ${seleccionado}>${etiqueta}</option>`;
      })
      .join('');
    return `<select id="${nombreCampo}" name="${nombreCampo}" ${requerido}>
      <option value="">Selecciona una opción</option>
      ${opcionesHtml}
    </select>`;
  }

  if (def.tipo === 'textarea') {
    return `<textarea id="${nombreCampo}" name="${nombreCampo}" rows="3" ${requerido}>${valorActual}</textarea>`;
  }

  return `<input type="${def.tipo}" id="${nombreCampo}" name="${nombreCampo}" value="${valorActual}" ${requerido}>`;
}

async function enrutar() {
  const ruta = window.location.hash.replace('#/', '');
  const partes = ruta.split('/').filter(Boolean);

  try {
    if (partes.length === 0) {
      await mostrarPanel();
    } else if (partes.length === 1) {
      await mostrarListado(partes[0]);
    } else if (partes[1] === 'nuevo') {
      await mostrarFormulario(partes[0]);
    } else if (partes[1] === 'editar') {
      await mostrarFormulario(partes[0], partes[2]);
    }
  } catch (error) {
    contenedor.innerHTML = `<div class="alerta alerta--error">${error.message}</div>`;
  }
}

window.addEventListener('hashchange', enrutar);
window.addEventListener('DOMContentLoaded', enrutar);
