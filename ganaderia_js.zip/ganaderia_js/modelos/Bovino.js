import Entidad from './Entidad.js';
import { obtenerPool } from '../host/conexion.js';

/**
 * Bovino
 * -----------------------------------------------------------------
 * Se relaciona con Raza (cada bovino tiene una raza). Por eso
 * sobreescribe listar(): además de traer sus propias columnas, hace
 * un JOIN para incluir el nombre de la raza relacionada. El resto
 * del CRUD (crear, actualizar, eliminar, obtenerPorId) lo hereda tal
 * cual de Entidad, sin tocarlo.
 */
export default class Bovino extends Entidad {
  constructor() {
    super('Bovino', 'ID_Bovino');
  }

  obtenerCampos() {
    return {
      Nombre_Bovino: { etiqueta: 'Nombre', tipo: 'text', requerido: true },
      ID_Raza: {
        etiqueta: 'Raza',
        tipo: 'select',
        fuente: 'raza',
        etiquetaRelacion: 'Nombre_Raza',
        requerido: true,
      },
      Fecha_Nacimiento: { etiqueta: 'Fecha de nacimiento', tipo: 'date', requerido: true },
    };
  }

  validar(datos) {
    const errores = [];
    if (!datos.Nombre_Bovino || !String(datos.Nombre_Bovino).trim()) errores.push('El nombre del bovino es obligatorio');
    if (!datos.ID_Raza) errores.push('Debe seleccionar una raza');
    if (!datos.Fecha_Nacimiento) errores.push('La fecha de nacimiento es obligatoria');
    return errores;
  }

  // POLIMORFISMO: esta hija necesita traer el nombre de la raza
  // relacionada, así que sobreescribe el listar() genérico de Entidad.
  async listar(orden = null) {
    const pool = await obtenerPool();
    const campoOrden = orden || `b.${this.llavePrimaria}`;
    const resultado = await pool.request().query(`
      SELECT b.*, r.Nombre_Raza
      FROM Bovino b
      LEFT JOIN Raza r ON b.ID_Raza = r.ID_Raza
      ORDER BY ${campoOrden}
    `);
    return resultado.recordset;
  }
}
