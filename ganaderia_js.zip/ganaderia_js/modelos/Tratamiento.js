import Entidad from './Entidad.js';
import { obtenerPool } from '../host/conexion.js';

class Tratamiento extends Entidad {
  constructor() {
    super('TRATAMIENTO', 'ID_Tratamiento');
  }

  obtenerCampos() {
    return {
      ID_Enfermedad: {
        etiqueta: 'Enfermedad',
        tipo: 'select',
        fuente: 'enfermedad',
        etiquetaRelacion: 'Nombre_Enfermedad',
        requerido: true,
      },
      Nombre_Medicamentos: { etiqueta: 'Medicamento', tipo: 'text', requerido: true },
      Dosis: { etiqueta: 'Dosis', tipo: 'number', requerido: true },
      Unidad_Dosis: { etiqueta: 'Unidad de dosis', tipo: 'text', requerido: true },
    };
  }

  validar(datos) {
    const errores = [];
    if (!datos.ID_Enfermedad) errores.push('Debe seleccionar una enfermedad');
    if (!datos.Nombre_Medicamentos || !String(datos.Nombre_Medicamentos).trim()) errores.push('El medicamento es obligatorio');
    if (datos.Dosis === undefined || datos.Dosis === '' || isNaN(Number(datos.Dosis))) errores.push('La dosis debe ser numérica');
    if (!datos.Unidad_Dosis || !String(datos.Unidad_Dosis).trim()) errores.push('La unidad de dosis es obligatoria');
    return errores;
  }

  async listar(orden = null) {
    const pool = await obtenerPool();
    const campoOrden = orden || `t.${this.llavePrimaria}`;
    const resultado = await pool.request().query(`
      SELECT t.*, e.Nombre_Enfermedad
      FROM TRATAMIENTO t
      LEFT JOIN ENFERMEDAD e ON t.ID_Enfermedad = e.ID_Enfermedad
      ORDER BY ${campoOrden}
    `);
    return resultado.recordset;
  }
}

export default Tratamiento;