import Entidad from './Entidad.js';
import { obtenerPool } from '../host/conexion.js';

class Historial extends Entidad {
  constructor() {
    super('Historial', 'ID_Historial');
  }

  obtenerCampos() {
    return {
      ID_Bovino: {
        etiqueta: 'Bovino',
        tipo: 'select',
        fuente: 'bovino',
        etiquetaRelacion: 'Nombre_Bovino',
        requerido: true,
      },
      ID_Tratamiento: {
        etiqueta: 'Tratamiento',
        tipo: 'select',
        fuente: 'tratamiento',
        etiquetaRelacion: 'Nombre_Medicamentos',
        requerido: true,
      },
      Fecha_Diagnostico: { etiqueta: 'Fecha de diagnóstico', tipo: 'date', requerido: true },
    };
  }

  validar(datos) {
    const errores = [];
    if (!datos.ID_Bovino) errores.push('Debe seleccionar un bovino');
    if (!datos.ID_Tratamiento) errores.push('Debe seleccionar un tratamiento');
    if (!datos.Fecha_Diagnostico) errores.push('La fecha de diagnóstico es obligatoria');
    return errores;
  }

  async listar(orden = null) {
    const pool = await obtenerPool();
    const campoOrden = orden || `h.${this.llavePrimaria}`;
    const resultado = await pool.request().query(`
      SELECT h.*, b.Nombre_Bovino, tr.Nombre_Medicamentos
      FROM Historial h
      LEFT JOIN Bovino b ON h.ID_Bovino = b.ID_Bovino
      LEFT JOIN TRATAMIENTO tr ON h.ID_Tratamiento = tr.ID_Tratamiento
      ORDER BY ${campoOrden}
    `);
    return resultado.recordset;
  }
}

export default Historial;