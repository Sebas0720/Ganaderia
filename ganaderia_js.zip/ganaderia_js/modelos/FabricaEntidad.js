import Raza from './Raza.js';
import Enfermedad from './Enfermedad.js';
import Bovino from './Bovino.js';
import Tratamiento from './Tratamiento.js';
import Historial from './Historial.js';

/**
 * FabricaEntidad
 * -----------------------------------------------------------------
 * Fábrica (patrón "Factory"): sabe qué clase concreta crear según el
 * nombre de entidad que llega por la URL (por ejemplo "bovino" -> new
 * Bovino()). Gracias a esto, el controlador y las rutas nunca
 * preguntan "¿de qué clase concreta es este objeto?" — solo usan lo
 * que la fábrica les entrega como si fuera un Entidad genérico, y cada
 * una responde a su manera -> eso es POLIMORFISMO.
 *
 * ENCAPSULAMIENTO: el mapa de entidades es un CAMPO PRIVADO Y ESTÁTICO
 * (#mapa). Nadie de afuera puede leerlo ni modificarlo directamente;
 * solo se accede a través de los métodos de abajo.
 */
export default class FabricaEntidad {
  static #mapa = {
    raza: { Clase: Raza, titulo: 'Razas' },
    enfermedad: { Clase: Enfermedad, titulo: 'Enfermedades' },
    bovino: { Clase: Bovino, titulo: 'Bovinos' },
    tratamiento: { Clase: Tratamiento, titulo: 'Tratamientos' },
    historial: { Clase: Historial, titulo: 'Historial médico' },
  };

  // Getter estático de solo lectura: entrega una COPIA del mapa interno,
  // nunca el objeto privado real, para que nadie lo pueda mutar desde afuera.
  static get entidadesDisponibles() {
    return { ...FabricaEntidad.#mapa };
  }

  static crear(nombre) {
    const entrada = FabricaEntidad.#mapa[String(nombre).toLowerCase()];
    if (!entrada) throw new Error(`La entidad "${nombre}" no existe`);
    return new entrada.Clase();
  }

  static listaEntidades() {
    return Object.entries(FabricaEntidad.#mapa).map(([clave, valor]) => ({ clave, titulo: valor.titulo }));
  }

  static titulo(nombre) {
    return FabricaEntidad.#mapa[String(nombre).toLowerCase()]?.titulo || nombre;
  }
}
