import Raza from './Raza.js';
import Enfermedad from './Enfermedad.js';
import Bovino from './Bovino.js';
import Tratamiento from './Tratamiento.js';
import Historial from './Historial.js';


const MAPA = {
  raza: { Clase: Raza, titulo: 'Razas' },
  enfermedad: { Clase: Enfermedad, titulo: 'Enfermedades' },
  bovino: { Clase: Bovino, titulo: 'Bovinos' },
  tratamiento: { Clase: Tratamiento, titulo: 'Tratamientos' },
  historial: { Clase: Historial, titulo: 'Historial médico' },
};

function crear(nombre) {
  const entrada = MAPA[String(nombre).toLowerCase()];
  if (!entrada) throw new Error(`La entidad "${nombre}" no existe`);
  return new entrada.Clase();
}

function listaEntidades() {
  return Object.entries(MAPA).map(([clave, valor]) => ({ clave, titulo: valor.titulo }));
}

function titulo(nombre) {
  return MAPA[String(nombre).toLowerCase()]?.titulo || nombre;
}

export { crear, listaEntidades, titulo };