import Entidad from './Entidad.js';

/**
 * Enfermedad
 * -----------------------------------------------------------------
 * Igual que Raza: no necesita relacionarse con otra tabla, así que le
 * alcanza con heredar el listar() genérico de Entidad sin sobreescribirlo.
 */
export default class Enfermedad extends Entidad {
  constructor() {
    super('ENFERMEDAD', 'ID_Enfermedad');
  }

  obtenerCampos() {
    return {
      Nombre_Enfermedad: { etiqueta: 'Nombre de la enfermedad', tipo: 'text', requerido: true },
      descripcion: { etiqueta: 'Descripción', tipo: 'textarea', requerido: false },
    };
  }

  validar(datos) {
    const errores = [];
    if (!datos.Nombre_Enfermedad || !String(datos.Nombre_Enfermedad).trim()) {
      errores.push('El nombre de la enfermedad es obligatorio');
    }
    return errores;
  }
}
