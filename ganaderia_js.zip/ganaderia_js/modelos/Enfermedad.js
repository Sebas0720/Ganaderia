import Entidad from './Entidad.js';

class Enfermedad extends Entidad {
  constructor() {
    super('ENFERMEDAD', 'ID_Enfermedad');
  }

  obtenerCampos() {
    return {
      Nombre_Enfermedad: { etiqueta: 'Nombre de la enfermedad', tipo: 'text', requerido: true },
      descripcion: { etiqueta: 'Descripción', tipo: 'textarea', requerido: false },
    };
  }

  validar(datos) {
    const errores = [];
    if (!datos.Nombre_Enfermedad || !String(datos.Nombre_Enfermedad).trim()) {
      errores.push('El nombre de la enfermedad es obligatorio');
    }
    return errores;
  }
}

export default Enfermedad;