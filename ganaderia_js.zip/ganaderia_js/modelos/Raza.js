import Entidad from './Entidad.js';

class Raza extends Entidad {
  constructor() {
    super('Raza', 'ID_Raza');
  }

  obtenerCampos() {
    return {
      Nombre_Raza: { etiqueta: 'Nombre de la raza', tipo: 'text', requerido: true },
    };
  }

  validar(datos) {
    const errores = [];
    if (!datos.Nombre_Raza || !String(datos.Nombre_Raza).trim()) {
      errores.push('El nombre de la raza es obligatorio');
    }
    return errores;
  }
}

export default Raza;
