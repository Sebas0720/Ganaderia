import Entidad from './Entidad.js';

/**
 * Raza
 * -----------------------------------------------------------------
 * Entidad más simple del proyecto: hereda TODO el motor CRUD de
 * Entidad (crear, listar, actualizar, eliminar) y solo aporta lo que
 * la hace única: sus campos de formulario y sus reglas de validación.
 */
export default class Raza extends Entidad {
  constructor() {
    super('Raza', 'ID_Raza');
  }

  obtenerCampos() {
    return {
      Nombre_Raza: { etiqueta: 'Nombre de la raza', tipo: 'text', requerido: true },
    };
  }

  validar(datos) {
    const errores = [];
    if (!datos.Nombre_Raza || !String(datos.Nombre_Raza).trim()) {
      errores.push('El nombre de la raza es obligatorio');
    }
    return errores;
  }
}
