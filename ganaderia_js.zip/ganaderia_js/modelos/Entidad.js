import { obtenerPool, obtenerSqlActivo } from '../host/conexion.js';

/**
 * Entidad
 * -----------------------------------------------------------------
 * Clase ABSTRACTA: no se puede crear un objeto "Entidad" directo (el
 * constructor lo bloquea), solo tiene sentido a través de una subclase
 * (Raza, Bovino, Enfermedad, Tratamiento, Historial). Aquí vive el
 * motor CRUD genérico (crear, listar, actualizar, eliminar) que TODAS
 * las hijas heredan sin tener que reescribirlo -> HERENCIA.
 *
 * obtenerCampos() y validar() son "métodos abstractos": esta clase los
 * declara pero los deja sin implementar a propósito (lanzan error si
 * se llaman); cada hija los sobreescribe con su propia lógica. listar()
 * sí tiene una implementación por defecto, pero las hijas que necesitan
 * JOINs (Bovino, Tratamiento, Historial) la sobreescriben -> eso es
 * POLIMORFISMO: el controlador llama siempre a "modelo.listar()" sin
 * saber ni importarle cuál subclase está usando en verdad.
 *
 * ENCAPSULAMIENTO: el nombre de la tabla y el nombre de la llave
 * primaria se guardan en CAMPOS PRIVADOS (#tabla, #llavePrimaria).
 * Nadie puede tocarlos directamente desde afuera; solo se puede leer
 * su valor con los getters, o cambiarlo con los setters (que además
 * validan que no llegue un valor vacío o inválido).
 */
export default class Entidad {
  #tabla;
  #llavePrimaria;

  constructor(tabla, llavePrimaria) {
    if (new.target === Entidad) {
      throw new Error('Entidad es una clase abstracta: crea una subclase en su lugar.');
    }
    this.tabla = tabla;
    this.llavePrimaria = llavePrimaria;
  }

  get tabla() {
    return this.#tabla;
  }

  get llavePrimaria() {
    return this.#llavePrimaria;
  }

  set tabla(valor) {
    if (!valor || typeof valor !== 'string') {
      throw new Error('El nombre de la tabla debe ser un texto no vacío');
    }
    this.#tabla = valor;
  }

  set llavePrimaria(valor) {
    if (!valor || typeof valor !== 'string') {
      throw new Error('El nombre de la llave primaria debe ser un texto no vacío');
    }
    this.#llavePrimaria = valor;
  }

  // Getter derivado: lo CALCULA al vuelo llamando a obtenerCampos()
  // (que cada hija implementa distinto) -> también aprovecha el
  // polimorfismo, porque usa "this.obtenerCampos()".
  get camposRequeridos() {
    return Object.entries(this.obtenerCampos())
      .filter(([, definicion]) => definicion.requerido)
      .map(([nombreCampo]) => nombreCampo);
  }

  obtenerCampos() {
    throw new Error(`obtenerCampos() no fue implementado en ${this.constructor.name}`);
  }

  validar(_datos) {
    throw new Error(`validar() no fue implementado en ${this.constructor.name}`);
  }

  // Consulta genérica. Las hijas con relaciones la sobreescriben (polimorfismo).
  async listar(orden = null) {
    const pool = await obtenerPool();
    const campoOrden = orden || this.llavePrimaria;
    const resultado = await pool.request().query(`SELECT * FROM ${this.tabla} ORDER BY ${campoOrden}`);
    return resultado.recordset;
  }

  async obtenerPorId(id) {
    const pool = await obtenerPool();
    const resultado = await pool
      .request()
      .input('id', obtenerSqlActivo().Int, id)
      .query(`SELECT * FROM ${this.tabla} WHERE ${this.llavePrimaria} = @id`);
    return resultado.recordset[0] || null;
  }

  async crear(datos) {
    const errores = this.validar(datos);
    if (errores.length) throw new Error(errores.join(' | '));

    const pool = await obtenerPool();
    const peticion = pool.request();
    const columnas = Object.keys(datos);
    columnas.forEach((columna) => peticion.input(columna, datos[columna]));

    const marcadores = columnas.map((c) => `@${c}`).join(', ');
    const consulta = `INSERT INTO ${this.tabla} (${columnas.join(', ')}) OUTPUT INSERTED.* VALUES (${marcadores})`;
    const resultado = await peticion.query(consulta);
    return resultado.recordset[0];
  }

  async actualizar(id, datos) {
    const errores = this.validar(datos);
    if (errores.length) throw new Error(errores.join(' | '));

    const pool = await obtenerPool();
    const peticion = pool.request().input('id', obtenerSqlActivo().Int, id);
    const columnas = Object.keys(datos);
    columnas.forEach((columna) => peticion.input(columna, datos[columna]));

    const asignaciones = columnas.map((c) => `${c} = @${c}`).join(', ');
    await peticion.query(`UPDATE ${this.tabla} SET ${asignaciones} WHERE ${this.llavePrimaria} = @id`);
    return this.obtenerPorId(id);
  }

  async eliminar(id) {
    const pool = await obtenerPool();
    await pool
      .request()
      .input('id', obtenerSqlActivo().Int, id)
      .query(`DELETE FROM ${this.tabla} WHERE ${this.llavePrimaria} = @id`);
    return { eliminado: true, id };
  }
}
