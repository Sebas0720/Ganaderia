const conexion = require('../host/conexion');
const { obtenerPool } = conexion;

/**
 * Entidad
 * Clase abstracta: no debe instanciarse directamente (se lanza un error
 * si se intenta). Aquí vive el motor CRUD genérico que TODAS las
 * entidades hijas heredan sin reescribirlo.
 *
 * obtenerCampos() y validar() son "métodos abstractos": cada hija está
 * obligada a implementarlos con su propia lógica -> esto es el contrato
 * de polimorfismo del proyecto. listar() tiene una versión por defecto,
 * pero las hijas que necesitan JOINs (Bovino, Tratamiento, Historial) la
 * sobreescriben.
 *
 * IMPORTANTE: "sql" (para sql.Int, etc.) se lee como conexion.sql en
 * cada método, NO se destructura arriba del archivo. conexion.sql es un
 * getter que solo tiene valor real DESPUÉS de que obtenerPool() conectó
 * por primera vez; si se destructura una sola vez al cargar el módulo,
 * queda "congelado" en null para siempre.
 */
class Entidad {
  constructor(tabla, llavePrimaria) {
    if (new.target === Entidad) {
      throw new Error('Entidad es una clase abstracta: crea una subclase en su lugar.');
    }
    this.tabla = tabla;
    this.llavePrimaria = llavePrimaria;
  }

  obtenerCampos() {
    throw new Error(`obtenerCampos() no fue implementado en ${this.constructor.name}`);
  }

  validar(_datos) {
    throw new Error(`validar() no fue implementado en ${this.constructor.name}`);
  }

  // Consulta genérica. Las hijas con relaciones la sobreescriben (polimorfismo).
  async listar(orden = null) {
    const pool = await obtenerPool();
    const campoOrden = orden || this.llavePrimaria;
    const resultado = await pool.request().query(`SELECT * FROM ${this.tabla} ORDER BY ${campoOrden}`);
    return resultado.recordset;
  }

  async obtenerPorId(id) {
    const pool = await obtenerPool();
    const resultado = await pool
      .request()
      .input('id', conexion.sql.Int, id)
      .query(`SELECT * FROM ${this.tabla} WHERE ${this.llavePrimaria} = @id`);
    return resultado.recordset[0] || null;
  }

  async crear(datos) {
    const errores = this.validar(datos);
    if (errores.length) throw new Error(errores.join(' | '));

    const pool = await obtenerPool();
    const peticion = pool.request();
    const columnas = Object.keys(datos);
    columnas.forEach((columna) => peticion.input(columna, datos[columna]));

    const marcadores = columnas.map((c) => `@${c}`).join(', ');
    const consulta = `INSERT INTO ${this.tabla} (${columnas.join(', ')}) OUTPUT INSERTED.* VALUES (${marcadores})`;
    const resultado = await peticion.query(consulta);
    return resultado.recordset[0];
  }

  async actualizar(id, datos) {
    const errores = this.validar(datos);
    if (errores.length) throw new Error(errores.join(' | '));

    const pool = await obtenerPool();
    const peticion = pool.request().input('id', conexion.sql.Int, id);
    const columnas = Object.keys(datos);
    columnas.forEach((columna) => peticion.input(columna, datos[columna]));

    const asignaciones = columnas.map((c) => `${c} = @${c}`).join(', ');
    await peticion.query(`UPDATE ${this.tabla} SET ${asignaciones} WHERE ${this.llavePrimaria} = @id`);
    return this.obtenerPorId(id);
  }

  async eliminar(id) {
    const pool = await obtenerPool();
    await pool.request().input('id', conexion.sql.Int, id).query(`DELETE FROM ${this.tabla} WHERE ${this.llavePrimaria} = @id`);
    return { eliminado: true, id };
  }
}

module.exports = Entidad;