const config = require('./config');

let promesaPool = null;
let sqlActivo = null;

function destinoLegible() {
  return config.instancia ? `${config.servidor}\\${config.instancia}` : config.servidor;
}

function conectarConWindowsAuth() {
  const sql = require('mssql/msnodesqlv8');
  sqlActivo = sql;

  return sql
    .connect({
      driver: 'msnodesqlv8',
      server: destinoLegible(),
      database: config.baseDatos,
      options: {
        trustedConnection: true,
      },
    })
    .then((pool) => {
      console.log(`Conectado a SQL Server (${destinoLegible()}/${config.baseDatos}) con Autenticación de Windows ✓`);
      return pool;
    })
    .catch((error) => {
      promesaPool = null;
      console.error(`No fue posible conectar a SQL Server (${destinoLegible()}/${config.baseDatos}):`, error);
      console.error(
        'Checklist Autenticación de Windows: ' +
        '1) "npm install mssql msnodesqlv8" terminó sin errores, ' +
        '2) tienes instalado "ODBC Driver 17" o "18 for SQL Server" (Microsoft), ' +
        '3) el servicio "SQL Server Browser" está iniciado, ' +
        '4) tu usuario de Windows aparece con acceso en SSMS -> Seguridad -> Inicios de sesión.'
      );
      throw error;
    });
}

function conectarConSqlAuth() {
  const sql = require('mssql');
  sqlActivo = sql;

  const configuracionSql = {
    user: config.usuario,
    password: config.clave,
    server: config.servidor,
    database: config.baseDatos,
    options: {
      encrypt: config.encriptar,
      trustServerCertificate: true,
      ...(config.instancia ? { instanceName: config.instancia } : {}),
    },
  };
  if (!config.instancia) configuracionSql.port = config.puerto || 1433;

  return new sql.ConnectionPool(configuracionSql)
    .connect()
    .then((pool) => {
      console.log(`Conectado a SQL Server (${destinoLegible()}/${config.baseDatos}) con Autenticación de SQL Server ✓`);
      return pool;
    })
    .catch((error) => {
      promesaPool = null;
      console.error(`No fue posible conectar a SQL Server (${destinoLegible()}/${config.baseDatos}):`, error);
      console.error(
        'Checklist Autenticación de SQL Server: ' +
        '1) Modo de autenticación mixto habilitado (SSMS -> Propiedades del servidor -> Seguridad), ' +
        '2) el login (ej. "sa") está Habilitado y con la contraseña correcta, ' +
        '3) servicio "SQL Server Browser" iniciado y TCP/IP habilitado si usas instancia con nombre.'
      );
      throw error;
    });
}

function obtenerPool() {
  if (!promesaPool) {
    promesaPool = config.autenticacionWindows ? conectarConWindowsAuth() : conectarConSqlAuth();
  }
  return promesaPool;
}

module.exports = {
  obtenerPool,
  get sql() {
    return sqlActivo;
  },
};