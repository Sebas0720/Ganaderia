module.exports = {
  servidor: process.env.DB_SERVIDOR || 'localhost',
  instancia: process.env.DB_INSTANCIA || 'SQLEXPRESS',
  baseDatos: process.env.DB_NOMBRE || 'GanaderiaDB',
  autenticacionWindows: false,
  usuario: process.env.DB_USUARIO || 'sa',
  clave: process.env.DB_CLAVE || 'Sebach07',
  puerto: process.env.DB_PUERTO ? parseInt(process.env.DB_PUERTO, 10) : null,
  encriptar: process.env.DB_ENCRYPT === 'true',
};