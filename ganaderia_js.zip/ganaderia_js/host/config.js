/**
 * config.js
 * -----------------------------------------------------------------
 * Configuración de conexión a SQL Server.
 *
 * ENCAPSULAMIENTO: en vez de un objeto plano, se usa una CLASE con
 * campos PRIVADOS (los que empiezan con "#"). Solo esta clase puede
 * leer/escribir esos valores directamente; el resto del proyecto
 * solo puede leerlos con los getters, o cambiarlos con los setters.
 *
 * Los valores se leen de variables de entorno si existen; si no, se
 * usan los valores por defecto (los mismos que ya tenías).
 */
class ConfiguracionBaseDatos {
  #servidor;
  #instancia;
  #baseDatos;
  #autenticacionWindows;
  #usuario;
  #clave;
  #puerto;
  #encriptar;

  constructor() {
    this.#servidor = process.env.DB_SERVIDOR || 'localhost';
    this.#instancia = process.env.DB_INSTANCIA || 'SQLEXPRESS';
    this.#baseDatos = process.env.DB_NOMBRE || 'GanaderiaDB';
    this.#autenticacionWindows = false; // Autenticación de SQL Server (usuario y contraseña)
    this.#usuario = process.env.DB_USUARIO || 'sa';
    this.#clave = process.env.DB_CLAVE || 'Sebach07';
    this.#puerto = process.env.DB_PUERTO ? parseInt(process.env.DB_PUERTO, 10) : null;
    this.#encriptar = process.env.DB_ENCRYPT === 'true';
  }

  // --- Getters: forma de LEER cada dato privado desde otros archivos ---
  get servidor() { return this.#servidor; }
  get instancia() { return this.#instancia; }
  get baseDatos() { return this.#baseDatos; }
  get autenticacionWindows() { return this.#autenticacionWindows; }
  get usuario() { return this.#usuario; }
  get clave() { return this.#clave; }
  get puerto() { return this.#puerto; }
  get encriptar() { return this.#encriptar; }

  // --- Setters: forma CONTROLADA de cambiar un valor en caliente ---
  set autenticacionWindows(valor) {
    this.#autenticacionWindows = Boolean(valor);
  }

  set clave(valorNuevo) {
    if (!valorNuevo || typeof valorNuevo !== 'string') {
      throw new Error('La contraseña debe ser un texto no vacío');
    }
    this.#clave = valorNuevo;
  }
}

// Se exporta UNA sola instancia ya construida (patrón Singleton): todo
// el proyecto comparte exactamente la misma configuración en memoria.
export default new ConfiguracionBaseDatos();
