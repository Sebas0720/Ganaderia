/**
 * conexion.js
 * Crea y reutiliza un único pool de conexiones a SQL Server, eligiendo
 * el driver según config.autenticacionWindows:
 *
 *  - Windows Authentication (true, por defecto, como en tu SSMS):
 *      usa "mssql/msnodesqlv8" + Trusted_Connection.
 *      Instalación requerida (SOLO Windows):
 *        npm install mssql msnodesqlv8
 *      Además necesitas instalado en tu equipo el
 *      "ODBC Driver 17" o "18 for SQL Server" (Microsoft), y el
 *      servicio "SQL Server Browser" iniciado (por la instancia con
 *      nombre SQLEXPRESS).
 *
 *  - SQL Server Authentication (false, usuario y contraseña):
 *      usa "mssql" a secas (driver tedious, funciona en cualquier SO).
 *      Instalación requerida:
 *        npm install mssql
 *
 * Si "msnodesqlv8" te da problemas al instalar (necesita compilar un
 * módulo nativo), la alternativa más simple es poner
 * autenticacionWindows: false en config.js, habilitar el modo de
 * autenticación mixta en SSMS y usar un login de SQL Server (ej. "sa").
 */
const config = require('./config');

let promesaPool = null;
let sqlActivo = null; // guarda el objeto "sql" del driver que quedó activo (para sql.Int, etc.)

function destinoLegible() {
  return config.instancia ? `${config.servidor}\\${config.instancia}` : config.servidor;
}

function conectarConWindowsAuth() {
  // Se importa aquí adentro (y no arriba del archivo) para que el
  // proyecto no truene si "msnodesqlv8" no está instalado y esta
  // rama nunca se ejecuta (por ejemplo, en Linux/Mac).
  const sql = require('mssql/msnodesqlv8');
  sqlActivo = sql;

  return sql
    .connect({
      driver: 'msnodesqlv8',
      server: destinoLegible(),
      database: config.baseDatos,
      options: {
        trustedConnection: true, // equivalente a "Autenticación de Windows" en SSMS
      },
    })
    .then((pool) => {
      console.log(`Conectado a SQL Server (${destinoLegible()}/${config.baseDatos}) con Autenticación de Windows ✓`);
      return pool;
    })
    .catch((error) => {
      promesaPool = null;
      console.error(`No fue posible conectar a SQL Server (${destinoLegible()}/${config.baseDatos}):`, error);
      console.error(
        'Checklist Autenticación de Windows: ' +
        '1) "npm install mssql msnodesqlv8" terminó sin errores, ' +
        '2) tienes instalado "ODBC Driver 17" o "18 for SQL Server" (Microsoft), ' +
        '3) el servicio "SQL Server Browser" está iniciado, ' +
        '4) tu usuario de Windows aparece con acceso en SSMS -> Seguridad -> Inicios de sesión.'
      );
      throw error;
    });
}

function conectarConSqlAuth() {
  const sql = require('mssql');
  sqlActivo = sql;

  const configuracionSql = {
    user: config.usuario,
    password: config.clave,
    server: config.servidor, // solo el host, SIN "\instancia" aquí
    database: config.baseDatos,
    options: {
      encrypt: config.encriptar,
      trustServerCertificate: true,
      ...(config.instancia ? { instanceName: config.instancia } : {}),
    },
  };
  if (!config.instancia) configuracionSql.port = config.puerto || 1433;

  return new sql.ConnectionPool(configuracionSql)
    .connect()
    .then((pool) => {
      console.log(`Conectado a SQL Server (${destinoLegible()}/${config.baseDatos}) con Autenticación de SQL Server ✓`);
      return pool;
    })
    .catch((error) => {
      promesaPool = null;
      console.error(`No fue posible conectar a SQL Server (${destinoLegible()}/${config.baseDatos}):`, error);
      console.error(
        'Checklist Autenticación de SQL Server: ' +
        '1) Modo de autenticación mixto habilitado (SSMS -> Propiedades del servidor -> Seguridad), ' +
        '2) el login (ej. "sa") está Habilitado y con la contraseña correcta, ' +
        '3) servicio "SQL Server Browser" iniciado y TCP/IP habilitado si usas instancia con nombre.'
      );
      throw error;
    });
}

function obtenerPool() {
  if (!promesaPool) {
    promesaPool = config.autenticacionWindows ? conectarConWindowsAuth() : conectarConSqlAuth();
  }
  return promesaPool;
}

module.exports = {
  obtenerPool,
  // Los modelos hacen `const { obtenerPool, sql } = require('../host/conexion')`
  // y usan sql.Int, etc. Este getter siempre devuelve el driver que quedó
  // activo (tedious o msnodesqlv8), sin que los modelos tengan que saber cuál es.
  get sql() {
    return sqlActivo;
  },
};