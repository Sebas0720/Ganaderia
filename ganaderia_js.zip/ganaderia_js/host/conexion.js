/**
 * conexion.js
 * -----------------------------------------------------------------
 * Abre y reutiliza UNA sola conexión (pool) hacia SQL Server, usando
 * el modo de autenticación que diga config.js (SQL Server o Windows).
 *
 * ENCAPSULAMIENTO: "ConexionSqlServer" guarda su estado (el pool ya
 * conectado, y qué versión de la librería "sql" quedó activa) en
 * CAMPOS PRIVADOS ESTÁTICOS (#promesaPool, #sqlActivo). Nadie fuera
 * de esta clase puede leer o pisar esas dos variables directamente.
 *
 * mssql y msnodesqlv8 se cargan con "import()" DINÁMICO (en vez de un
 * import normal arriba del archivo) porque solo uno de los dos hace
 * falta según el modo de autenticación, y así el proyecto no truena
 * si msnodesqlv8 no está instalado y nunca se usa esa rama.
 */
import configuracion from './config.js';

class ConexionSqlServer {
  static #promesaPool = null;
  static #sqlActivo = null;

  // Método privado: arma "host\instancia" solo para mostrarlo en los logs.
  static #destinoLegible() {
    return configuracion.instancia
      ? `${configuracion.servidor}\\${configuracion.instancia}`
      : configuracion.servidor;
  }

  // Conecta usando el driver nativo "msnodesqlv8" (Autenticación de
  // Windows, como en SSMS). Solo funciona en Windows y requiere el
  // ODBC Driver de SQL Server instalado.
  static async #conectarConWindowsAuth() {
    const { default: sql } = await import('mssql/msnodesqlv8');
    ConexionSqlServer.#sqlActivo = sql;

    try {
      const pool = await sql.connect({
        driver: 'msnodesqlv8',
        server: ConexionSqlServer.#destinoLegible(),
        database: configuracion.baseDatos,
        options: {
          trustedConnection: true, // equivalente a "Autenticación de Windows" en SSMS
        },
      });
      console.log(
        `Conectado a SQL Server (${ConexionSqlServer.#destinoLegible()}/${configuracion.baseDatos}) con Autenticación de Windows ✓`
      );
      return pool;
    } catch (error) {
      ConexionSqlServer.#promesaPool = null;
      console.error(
        `No fue posible conectar a SQL Server (${ConexionSqlServer.#destinoLegible()}/${configuracion.baseDatos}):`,
        error
      );
      console.error(
        'Checklist Autenticación de Windows: ' +
          '1) "npm install mssql msnodesqlv8" terminó sin errores, ' +
          '2) tienes instalado "ODBC Driver 17" o "18 for SQL Server" (Microsoft), ' +
          '3) el servicio "SQL Server Browser" está iniciado, ' +
          '4) tu usuario de Windows aparece con acceso en SSMS -> Seguridad -> Inicios de sesión.'
      );
      throw error;
    }
  }

  // Conecta con usuario y contraseña de SQL Server (la que ya tienes
  // funcionando, con el login "sa"). Funciona en cualquier sistema
  // operativo, no necesita ningún módulo nativo.
  static async #conectarConSqlAuth() {
    const { default: sql } = await import('mssql');
    ConexionSqlServer.#sqlActivo = sql;

    const configuracionSql = {
      user: configuracion.usuario,
      password: configuracion.clave,
      server: configuracion.servidor, // solo el host, SIN "\instancia" aquí
      database: configuracion.baseDatos,
      options: {
        encrypt: configuracion.encriptar,
        trustServerCertificate: true,
        ...(configuracion.instancia ? { instanceName: configuracion.instancia } : {}),
      },
    };
    if (!configuracion.instancia) configuracionSql.port = configuracion.puerto || 1433;

    try {
      const pool = await new sql.ConnectionPool(configuracionSql).connect();
      console.log(
        `Conectado a SQL Server (${ConexionSqlServer.#destinoLegible()}/${configuracion.baseDatos}) con Autenticación de SQL Server ✓`
      );
      return pool;
    } catch (error) {
      ConexionSqlServer.#promesaPool = null;
      console.error(
        `No fue posible conectar a SQL Server (${ConexionSqlServer.#destinoLegible()}/${configuracion.baseDatos}):`,
        error
      );
      console.error(
        'Checklist Autenticación de SQL Server: ' +
          '1) Modo de autenticación mixto habilitado (SSMS -> Propiedades del servidor -> Seguridad), ' +
          '2) el login (ej. "sa") está Habilitado y con la contraseña correcta, ' +
          '3) servicio "SQL Server Browser" iniciado y TCP/IP habilitado si usas instancia con nombre.'
      );
      throw error;
    }
  }

  // Getter estático: entrega el objeto "sql" del driver que quedó
  // activo (tedious o msnodesqlv8), para poder usar sql.Int, etc.
  // Antes de la primera conexión exitosa, vale null.
  static get sql() {
    return ConexionSqlServer.#sqlActivo;
  }

  // Punto de entrada público: si ya hay una conexión en curso o lista,
  // la reutiliza; si no, arranca una nueva según el modo configurado.
  static obtenerPool() {
    if (!ConexionSqlServer.#promesaPool) {
      ConexionSqlServer.#promesaPool = configuracion.autenticacionWindows
        ? ConexionSqlServer.#conectarConWindowsAuth()
        : ConexionSqlServer.#conectarConSqlAuth();
    }
    return ConexionSqlServer.#promesaPool;
  }
}

// Se exportan funciones sueltas (en vez de la clase completa) para que
// los modelos puedan hacer "import { obtenerPool } from ..." tal como
// ya lo hacían. "sql" se expone como una función porque un getter de
// una clase no se puede "exportar" tal cual con export nombrado; así
// siempre se consulta el valor más reciente en vez de uno congelado.
export function obtenerPool() {
  return ConexionSqlServer.obtenerPool();
}

export function obtenerSqlActivo() {
  return ConexionSqlServer.sql;
}
