const express = require('express');
const enrutador = express.Router();
const controlador = require('../controladores/crudController');

enrutador.get('/entidades', controlador.listarEntidades);
enrutador.get('/:entidad/campos', controlador.obtenerCampos);
enrutador.get('/:entidad/opciones', controlador.obtenerOpciones);
enrutador.get('/:entidad', controlador.listarRegistros);
enrutador.post('/:entidad', controlador.crearRegistro);
enrutador.put('/:entidad/:id', controlador.actualizarRegistro);
enrutador.delete('/:entidad/:id', controlador.eliminarRegistro);

module.exports = enrutador;
