import express from 'express';
import * as controlador from '../controladores/crudController.js';

/**
 * rutasApi.js
 * -----------------------------------------------------------------
 * Define las URLs de la API REST y qué función del controlador
 * atiende cada una. ":entidad" es un parámetro dinámico: la misma
 * ruta sirve para "raza", "bovino", "enfermedad", etc. sin tener que
 * repetir código por cada una (de nuevo, gracias al polimorfismo del
 * controlador).
 */
const enrutador = express.Router();

enrutador.get('/entidades', controlador.listarEntidades);
enrutador.get('/:entidad/campos', controlador.obtenerCampos);
enrutador.get('/:entidad/opciones', controlador.obtenerOpciones);
enrutador.get('/:entidad', controlador.listarRegistros);
enrutador.post('/:entidad', controlador.crearRegistro);
enrutador.put('/:entidad/:id', controlador.actualizarRegistro);
enrutador.delete('/:entidad/:id', controlador.eliminarRegistro);

export default enrutador;
