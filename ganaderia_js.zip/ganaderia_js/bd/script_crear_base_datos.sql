CREATE DATABASE GanaderiaDB;
USE GanaderiaDB;

CREATE TABLE Raza (
    ID_Raza INT IDENTITY(1,1) PRIMARY KEY,
    Nombre_Raza VARCHAR(100) NOT NULL
);

CREATE TABLE Bovino (
    ID_Bovino INT IDENTITY(1,1) PRIMARY KEY,
    Nombre_Bovino VARCHAR(100) NOT NULL,
    ID_Raza INT NOT NULL,
    Fecha_Nacimiento DATE NOT NULL,
    CONSTRAINT FK_Bovino_Raza FOREIGN KEY (ID_Raza) REFERENCES Raza(ID_Raza)
);

CREATE TABLE ENFERMEDAD (
    ID_Enfermedad INT IDENTITY(1,1) PRIMARY KEY,
    Nombre_Enfermedad VARCHAR(100) NOT NULL,
    descripcion VARCHAR(500) NULL
);

CREATE TABLE TRATAMIENTO (
    ID_Tratamiento INT IDENTITY(1,1) PRIMARY KEY,
    ID_Enfermedad INT NOT NULL,
    Nombre_Medicamentos VARCHAR(150) NOT NULL,
    Dosis DECIMAL(10,2) NOT NULL,
    Unidad_Dosis VARCHAR(30) NOT NULL,
    CONSTRAINT FK_Tratamiento_Enfermedad FOREIGN KEY (ID_Enfermedad) REFERENCES ENFERMEDAD(ID_Enfermedad)
);

CREATE TABLE Historial (
    ID_Historial INT IDENTITY(1,1) PRIMARY KEY,
    ID_Bovino INT NOT NULL,
    ID_Tratamiento INT NOT NULL,
    Fecha_Diagnostico DATE NOT NULL,
    CONSTRAINT FK_Historial_Bovino FOREIGN KEY (ID_Bovino) REFERENCES Bovino(ID_Bovino),
    CONSTRAINT FK_Historial_Tratamiento FOREIGN KEY (ID_Tratamiento) REFERENCES TRATAMIENTO(ID_Tratamiento)
);

INSERT INTO Raza (Nombre_Raza) VALUES ('Holstein'), ('Angus'), ('Brahman');
INSERT INTO ENFERMEDAD (Nombre_Enfermedad, descripcion) VALUES
    ('Mastitis', 'Inflamación de la glándula mamaria'),
    ('Fiebre aftosa', 'Enfermedad viral altamente contagiosa');