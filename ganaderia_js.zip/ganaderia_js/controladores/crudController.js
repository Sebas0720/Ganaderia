import FabricaEntidad from '../modelos/FabricaEntidad.js';

/**
 * crudController.js
 * -----------------------------------------------------------------
 * Un solo controlador para las 5 entidades (Raza, Bovino, Enfermedad,
 * Tratamiento, Historial). En cada función se hace
 * "FabricaEntidad.crear(req.params.entidad)" y, a partir de ahí, SIEMPRE
 * se llaman los mismos métodos (listar, crear, validar, etc.) sin
 * importar qué subclase concreta llegó -> POLIMORFISMO.
 */

export async function listarEntidades(_req, res) {
  res.json(FabricaEntidad.listaEntidades());
}

export async function obtenerCampos(req, res) {
  try {
    const modelo = FabricaEntidad.crear(req.params.entidad);
    res.json({
      campos: modelo.obtenerCampos(),
      llavePrimaria: modelo.llavePrimaria, // usa el GETTER de Entidad
      titulo: FabricaEntidad.titulo(req.params.entidad),
    });
  } catch (error) {
    res.status(404).json({ error: error.message });
  }
}

export async function listarRegistros(req, res) {
  try {
    const modelo = FabricaEntidad.crear(req.params.entidad);
    const registros = await modelo.listar();
    res.json(registros);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

export async function obtenerOpciones(req, res) {
  try {
    const modelo = FabricaEntidad.crear(req.params.entidad);
    const campos = modelo.obtenerCampos();
    const opciones = {};

    for (const [nombreCampo, definicion] of Object.entries(campos)) {
      if (definicion.tipo === 'select') {
        const modeloFuente = FabricaEntidad.crear(definicion.fuente);
        opciones[nombreCampo] = {
          llave: modeloFuente.llavePrimaria,
          registros: await modeloFuente.listar(),
        };
      }
    }

    res.json(opciones);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

export async function crearRegistro(req, res) {
  try {
    const modelo = FabricaEntidad.crear(req.params.entidad);
    const nuevo = await modelo.crear(req.body);
    res.status(201).json(nuevo);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
}

export async function actualizarRegistro(req, res) {
  try {
    const modelo = FabricaEntidad.crear(req.params.entidad);
    const actualizado = await modelo.actualizar(req.params.id, req.body);
    res.json(actualizado);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
}

export async function eliminarRegistro(req, res) {
  try {
    const modelo = FabricaEntidad.crear(req.params.entidad);
    const resultado = await modelo.eliminar(req.params.id);
    res.json(resultado);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
}
