const FabricaEntidad = require('../modelos/FabricaEntidad');


async function listarEntidades(_req, res) {
  res.json(FabricaEntidad.listaEntidades());
}

async function obtenerCampos(req, res) {
  try {
    const modelo = FabricaEntidad.crear(req.params.entidad);
    res.json({
      campos: modelo.obtenerCampos(),
      llavePrimaria: modelo.llavePrimaria,
      titulo: FabricaEntidad.titulo(req.params.entidad),
    });
  } catch (error) {
    res.status(404).json({ error: error.message });
  }
}

async function listarRegistros(req, res) {
  try {
    const modelo = FabricaEntidad.crear(req.params.entidad);
    const registros = await modelo.listar();
    res.json(registros);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}


async function obtenerOpciones(req, res) {
  try {
    const modelo = FabricaEntidad.crear(req.params.entidad);
    const campos = modelo.obtenerCampos();
    const opciones = {};

    for (const [nombreCampo, definicion] of Object.entries(campos)) {
      if (definicion.tipo === 'select') {
        const modeloFuente = FabricaEntidad.crear(definicion.fuente);
        opciones[nombreCampo] = {
          llave: modeloFuente.llavePrimaria,
          registros: await modeloFuente.listar(),
        };
      }
    }

    res.json(opciones);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

async function crearRegistro(req, res) {
  try {
    const modelo = FabricaEntidad.crear(req.params.entidad);
    const nuevo = await modelo.crear(req.body);
    res.status(201).json(nuevo);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
}

async function actualizarRegistro(req, res) {
  try {
    const modelo = FabricaEntidad.crear(req.params.entidad);
    const actualizado = await modelo.actualizar(req.params.id, req.body);
    res.json(actualizado);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
}

async function eliminarRegistro(req, res) {
  try {
    const modelo = FabricaEntidad.crear(req.params.entidad);
    const resultado = await modelo.eliminar(req.params.id);
    res.json(resultado);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
}

module.exports = {
  listarEntidades,
  obtenerCampos,
  listarRegistros,
  obtenerOpciones,
  crearRegistro,
  actualizarRegistro,
  eliminarRegistro,
};
